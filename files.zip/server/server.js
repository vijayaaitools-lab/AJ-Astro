/*
 AJ-Astro API server (Astronomy Engine option)
 Endpoints:
  - GET /api/panchang?date=YYYY-MM-DD&lat=...&lon=...
  - GET /api/numerology?name=Full+Name
  - GET /api/remedies?q=term
  - POST /api/daily-horoscope (proxy to Aztro API) or GET with sign/day
  - POST /api/kundli-matching  (JSON body with personA/personB details)

 Install & run:
   cd server
   npm install
   npm start
*/
const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch');
const fs = require('fs');
const path = require('path');

let Astronomy = null;
try {
  Astronomy = require('astronomy-engine');
} catch (e) {
  console.warn('astronomy-engine not installed. Run `npm install astronomy-engine` in server/ for accurate calculations.');
}

const app = express();
app.use(cors());
app.use(express.json());

// Load remedies dataset if present
const remediesPath = path.join(__dirname, 'data', 'remedies.json');
let remediesData = {};
try {
  remediesData = JSON.parse(fs.readFileSync(remediesPath, 'utf8'));
} catch (e) {
  remediesData = { note: 'No remedies dataset found. Place a JSON file at server/data/remedies.json' };
}

// Pythagorean numerology mapping
const numerologyMap = {
  A:1,J:1,S:1,
  B:2,K:2,T:2,
  C:3,L:3,U:3,
  D:4,M:4,V:4,
  E:5,N:5,W:5,
  F:6,O:6,X:6,
  G:7,P:7,Y:7,
  H:8,Q:8,Z:8,
  I:9,R:9
};
function computeNameNumber(name) {
  if (!name) return null;
  const letters = name.toUpperCase().replace(/[^A-Z]/g, '');
  if (!letters) return null;
  let sum = 0;
  for (const ch of letters) sum += numerologyMap[ch] || 0;
  return reduceNumber(sum);
}
function reduceNumber(n) {
  if (n === 11 || n === 22) return n;
  while (n > 9) {
    let s = 0;
    while (n > 0) { s += n % 10; n = Math.floor(n / 10); }
    n = s;
    if (n === 11 || n === 22) return n;
  }
  return n;
}

// Helpers
function toDateUTC(dateStr) {
  if (!dateStr) return new Date();
  return new Date(dateStr + 'T00:00:00Z');
}
function normalizeAngle(a) {
  a = a % 360;
  if (a < 0) a += 360;
  return a;
}
function getBasicPlanetLongitudesJS(date) {
  // Simple fallback approximations (not accurate) so server runs without astronomy-engine
  const d = new Date(date).getTime()/86400000;
  const sun = normalizeAngle((new Date(date).getUTCFullYear()%12)*30 + 100 * Math.sin(d/365));
  const moon = normalizeAngle((new Date(date).getUTCDate()%27)*13 + 200 * Math.sin(d/27));
  return { sun, moon };
}
async function getSunMoonLongitudes(date) {
  if (!Astronomy) return getBasicPlanetLongitudesJS(date);
  try {
    const dt = (date instanceof Date) ? date : new Date(date);
    // Astronomy Engine helper usage:
    // Use Astronomy.EclipticLongitude if available, otherwise use SunLongitude/MoonLongitude
    let sunDeg = 0, moonDeg = 0;
    if (typeof Astronomy.EclipticLongitude === 'function') {
      const sunEcl = Astronomy.EclipticLongitude('Sun', dt);
      const moonEcl = Astronomy.EclipticLongitude('Moon', dt);
      sunDeg = normalizeAngle(sunEcl.lon ?? sunEcl.longitude ?? sunEcl);
      moonDeg = normalizeAngle(moonEcl.lon ?? moonEcl.longitude ?? moonEcl);
    } else if (typeof Astronomy.SunLongitude === 'function') {
      sunDeg = normalizeAngle(Astronomy.SunLongitude(dt));
      moonDeg = normalizeAngle(Astronomy.MoonLongitude(dt));
    } else {
      // best-effort: use library's object APIs if present
      const sun = Astronomy.Sun ? Astronomy.Sun(dt) : null;
      const moon = Astronomy.Moon ? Astronomy.Moon(dt) : null;
      sunDeg = normalizeAngle((sun && (sun.lon || sun.longitude)) || 0);
      moonDeg = normalizeAngle((moon && (moon.lon || moon.longitude)) || 0);
    }
    return { sun: sunDeg, moon: moonDeg };
  } catch (err) {
    console.warn('astronomy-engine call failed, falling back to simple approximation:', err.message || err);
    return getBasicPlanetLongitudesJS(date);
  }
}

// Panchang calculation (tithi, nakshatra, yoga, karana) from longitudes
function computePanchangFromLongitudes(sunLon, moonLon) {
  const tithiDeg = normalizeAngle(moonLon - sunLon);
  const tithiIndex = Math.floor(tithiDeg / 12) + 1; // 1..30
  const nakshatraIndex = Math.floor((moonLon % 360) / (360/27)) + 1; // 1..27
  const yogaDeg = normalizeAngle(sunLon + moonLon);
  const yogaIndex = Math.floor(yogaDeg / (360/27)) + 1; // 1..27
  const karanaIndex = Math.floor(tithiDeg / 6) + 1; // 1..11
  return {
    tithi: { index: tithiIndex, name: `Tithi ${tithiIndex}` },
    nakshatra: { index: nakshatraIndex, name: `Nakshatra ${nakshatraIndex}` },
    yoga: { index: yogaIndex, name: `Yoga ${yogaIndex}` },
    karana: { index: karanaIndex, name: `Karana ${karanaIndex}` }
  };
}

// Endpoints

// Numerology
app.get('/api/numerology', (req, res) => {
  const name = req.query.name || '';
  const num = computeNameNumber(name);
  if (num === null) return res.status(400).json({ error: 'Invalid name' });
  res.json({ name, number: num });
});

// Remedies search
app.get('/api/remedies', (req, res) => {
  const q = (req.query.q || '').trim().toLowerCase();
  if (!q) return res.json({ data: remediesData });
  const results = [];
  for (const k of Object.keys(remediesData)) {
    if (k.toLowerCase().includes(q) || JSON.stringify(remediesData[k]).toLowerCase().includes(q)) {
      results.push({ key: k, remedies: remediesData[k] });
    }
  }
  res.json({ query: q, results });
});

// Panchang
app.get('/api/panchang', async (req, res) => {
  const dateStr = req.query.date;
  const lat = parseFloat(req.query.lat) || null;
  const lon = parseFloat(req.query.lon) || null;
  const date = toDateUTC(dateStr);
  const { sun, moon } = await getSunMoonLongitudes(date);
  const p = computePanchangFromLongitudes(sun, moon);

  // sunrise/sunset best-effort (requires astronomy-engine + observer)
  let sunTimes = null;
  if (Astronomy && lat !== null && lon !== null) {
    try {
      const observer = new Astronomy.Observer(lat, lon, 0);
      const sr = Astronomy.SearchSunrise(date, observer, 1);
      const ss = Astronomy.SearchSunset(date, observer, 1);
      sunTimes = { sunrise: sr.toISOString(), sunset: ss.toISOString() };
    } catch (err) {
      sunTimes = null;
    }
  }

  res.json({ date: date.toISOString().slice(0,10), lat, lon, sun, moon, panchang: p, sunTimes });
});

// Daily horoscope (proxy to Aztro)
app.post('/api/daily-horoscope', async (req, res) => {
  const sign = req.body.sign || req.query.sign || 'aries';
  const day = req.body.day || req.query.day || 'today';
  try {
    const response = await fetch('https://aztro.sameerkumar.website/?sign=' + encodeURIComponent(sign) + '&day=' + encodeURIComponent(day), {
      method: 'POST'
    });
    const data = await response.json();
    return res.json({ proxied: true, source: 'aztro', data });
  } catch (err) {
    return res.status(500).json({ error: 'Failed to fetch from Aztro', details: err.message });
  }
});

// Kundli matching (simplified placeholder now — will be replaced with full 36-Guna Milan)
app.post('/api/kundli-matching', async (req, res) => {
  const a = req.body.personA || {};
  const b = req.body.personB || {};
  if (!a.dob || !b.dob) return res.status(400).json({ error: 'Both personA.dob and personB.dob required' });

  const dateA = toDateUTC(a.dob);
  const dateB = toDateUTC(b.dob);
  const posA = await getSunMoonLongitudes(dateA);
  const posB = await getSunMoonLongitudes(dateB);
  const nakA = Math.floor((posA.moon % 360) / (360/27)) + 1;
  const nakB = Math.floor((posB.moon % 360) / (360/27)) + 1;

  // Simple nakshatra-diff based proxy score (0..36)
  const diff = Math.abs(nakA - nakB);
  const rela = 1 - (diff / 27);
  const score = Math.round(36 * Math.max(0, rela));

  res.json({
    personA: { dob: a.dob, moonLon: posA.moon, nakshatra: nakA },
    personB: { dob: b.dob, moonLon: posB.moon, nakshatra: nakB },
    score,
    details: { method: 'simplified-nakshatra-diff', note: 'Will replace with full 36-Guna Milan algorithm' }
  });
});

// Start
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`AJ-Astro API server listening on port ${port}`));