```markdown
# AJ-Astro — Simple Web App (Static)

This is a small static web app that includes:

- Home page with links to:
  - Horoscope
  - Birth Details
  - Numerology
  - Matching (placeholder)
- Birth Details page with a form (Name, DOB, Time, Place). Submitting navigates to the Horoscope Result page.
- Horoscope Result page showing dummy Sun Sign, Moon Sign, Ascendant and today's prediction. If provided, submitted form values are shown.
- Numerology page: input full name → computes a name numerology "life path number" using Pythagorean mapping and reduces it to a single-digit (preserving master numbers 11 and 22).
- Simple styling via Tailwind CSS CDN; top navigation on every page.

How to run:
- Open `index.html` in a web browser (no server required).

Files:
- index.html
- birth.html
- horoscope.html
- numerology.html
- matching.html

Feel free to modify the dummy horoscope output with real logic or integrate with a backend.
```