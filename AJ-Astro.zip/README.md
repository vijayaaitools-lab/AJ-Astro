# AJ-Astro

Simple astrology web app (AJ-Astro): panchang, kundli, numerology, daily horoscope proxy, remedies.

## Run locally

1. Install server dependencies:
```bash
cd server
npm install
```

2. Start server:
```bash
npm start
```

3. Open frontend pages:
- If using Cursor: open `public/index.html` with live preview.
- Or serve static files using any simple static server (or deploy to Vercel).

API endpoints:
- `GET /api/panchang?date=YYYY-MM-DD&lat=<lat>&lon=<lon>`
- `POST /api/kundli` JSON: { name,dob,time,lat,lon }
- `POST /api/kundli-matching` JSON: { personA, personB }
- `GET /api/numerology?name=Full+Name`
- `GET /api/remedies`
- `POST /api/daily-horoscope` JSON: { sign: "aries" }
