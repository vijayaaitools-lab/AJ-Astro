// server/server.js
import express from "express";
import cors from "cors";
import bodyParser from "body-parser";
import fetch from "node-fetch";
import { readFileSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";
import * as Astronomy from "astronomy-engine";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(bodyParser.json());

const PORT = process.env.PORT || 3000;

/* ------------------ Load Remedies Data ------------------ */
const remediesPath = path.join(__dirname, "data", "remedies.json");
let remedies = [];
try {
  remedies = JSON.parse(readFileSync(remediesPath, "utf-8"));
} catch (err) {
  console.error("❌ remedies.json missing or invalid:", err);
}

/* ------------------ Utilities ------------------ */
function normalizeDeg(d) {
  return ((d % 360) + 360) % 360;
}
function applyLahiri(tropicalLongitude) {
  // Simple Lahiri offset (approx). For production, replace with ephemeris-based ayanamsa calc.
  return normalizeDeg(tropicalLongitude - 24);
}

/* ------------------ Numerology (Pythagorean) ------------------ */
app.get("/api/numerology", (req, res) => {
  const name = (req.query.name || "").toString();
  if (!name) return res.status(400).json({ error: "Missing name query" });
  const map = {
    A:1,B:2,C:3,D:4,E:5,F:6,G:7,H:8,I:9,
    J:1,K:2,L:3,M:4,N:5,O:6,P:7,Q:8,R:9,
    S:1,T:2,U:3,V:4,W:5,X:6,Y:7,Z:8
  };
  let total = 0;
  for (let ch of name.toUpperCase()) if (map[ch]) total += map[ch];
  let reduced = total;
  while (reduced > 9 && reduced !== 11 && reduced !== 22) {
    reduced = reduced.toString().split("").map(Number).reduce((a,b)=>a+b,0);
  }
  res.json({ name, total, lifePathNumber: reduced });
});

/* ------------------ Remedies ------------------ */
app.get("/api/remedies", (req, res) => {
  res.json(remedies);
});

/* ------------------ Daily Horoscope Proxy (Aztro) ------------------ */
app.post("/api/daily-horoscope", async (req, res) => {
  const sign = (req.body.sign || "").toString().toLowerCase();
  if (!sign) return res.status(400).json({ error: "Missing sign" });
  try {
    const response = await fetch(`https://aztro.sameerkumar.website?sign=${encodeURIComponent(sign)}&day=today`, {
      method: "POST"
    });
    const data = await response.json();
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: "Aztro API unreachable", details: err.message });
  }
});

/* ------------------ Panchang (basic using Astronomy Engine) ------------------ */
app.get("/api/panchang", async (req, res) => {
  try {
    const { date, lat, lon } = req.query;
    if (!date || !lat || !lon) return res.status(400).json({ error: "Missing date, lat, lon" });

    const d = new Date(date);
    const time = new Astronomy.Time(d);
    const sunEqu = Astronomy.SunPosition(time);
    const moonEqu = Astronomy.MoonPosition(time);

    const sunLon = sunEqu.ecliptic_lon;
    const moonLon = moonEqu.ecliptic_lon;
    const sunSid = applyLahiri(sunLon);
    const moonSid = applyLahiri(moonLon);

    const diff = normalizeDeg(moonSid - sunSid);
    const tithi = Math.floor(diff / 12) + 1;
    const nakshatraIndex = Math.floor(moonSid / (360/27)) + 1;
    const yogaIndex = Math.floor(((sunSid + moonSid) % 360) / (360/27)) + 1;
    const karanaIndex = Math.floor(diff / 6) + 1;

    res.json({
      date,
      location: { lat: Number(lat), lon: Number(lon) },
      sunLongitude: sunSid,
      moonLongitude: moonSid,
      tithi,
      nakshatra: nakshatraIndex,
      yoga: yogaIndex,
      karana: karanaIndex
    });
  } catch (err) {
    res.status(500).json({ error: "Panchang calculation failed", details: err.message });
  }
});

/* ------------------ Kundli (basic planetary positions + ascendant using Astronomy Engine) ------------------ */
app.post("/api/kundli", async (req, res) => {
  try {
    const { name, dob, time, lat, lon } = req.body;
    if (!dob || !time || !lat || !lon) return res.status(400).json({ error: "Missing dob/time/lat/lon" });

    const dt = new Date(`${dob}T${time}`);
    const t = new Astronomy.Time(dt);

    const result = {};
    const sunPos = Astronomy.SunPosition(t);
    const moonPos = Astronomy.MoonPosition(t);
    result.Sun = applyLahiri(sunPos.ecliptic_lon);
    result.Moon = applyLahiri(moonPos.ecliptic_lon);

    const planets = ["Mercury","Venus","Mars","Jupiter","Saturn","Uranus","Neptune","Pluto"];
    for (let p of planets) {
      try {
        const fn = Astronomy[p];
        if (fn && typeof fn === "function") {
          const pos = fn(t);
          const lon = pos.ecliptic_lon ?? pos.longitude ?? null;
          result[p] = lon ? applyLahiri(lon) : null;
        } else {
          result[p] = null;
        }
      } catch (e) {
        result[p] = null;
      }
    }

    const observer = new Astronomy.Observer(Number(lat), Number(lon), 0);
    const asc = Astronomy.Ascendant(t, observer);
    result.Lagna = applyLahiri(asc.longitude);

    res.json({ name: name||null, datetime: dt.toISOString(), location:{lat:Number(lat),lon:Number(lon)}, planets: result });
  } catch (err) {
    res.status(500).json({ error: "Kundli calculation failed", details: err.message });
  }
});

/* ------------------ Placeholder Kundli Matching endpoint ------------------ */
app.post("/api/kundli-matching", (req, res) => {
  const { personA, personB } = req.body;
  if (!personA || !personB) return res.status(400).json({ error: "Missing personA or personB" });
  res.json({ score: 28, maxScore: 36, details: { message: "Placeholder; full 36-Guna engine coming next." } });
});

/* ------------------ Health-check ------------------ */
app.get("/api/health", (req, res) => res.json({ status: "ok", time: new Date().toISOString() }));

app.listen(PORT, () => {
  console.log(`🚀 AJ-Astro server running on http://localhost:${PORT}`);
});
